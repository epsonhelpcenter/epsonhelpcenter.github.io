EPSON SUPPORT WEBSITE

This folder contains a static, responsive informational website adapted from the supplied IObit support website layout.

FILES
- index.html: homepage
- support.html: support topic directory
- blog.html: searchable article directory
- articles/: 42 Epson printer help articles
- style.css: shared responsive styling
- sitemap.xml: sample sitemap
- robots.txt: crawler instructions

BEFORE PUBLISHING
1. Replace https://example.com/ in sitemap.xml and robots.txt with your own final domain.
2. Review all content and ensure every instruction matches the Epson models you intend to cover.
3. This is an independent informational website, not an official Epson support channel. Do not imply affiliation with Epson.
4. Upload the complete folder contents to your web hosting account, preserving the articles folder structure.
